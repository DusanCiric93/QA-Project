import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class RegistrujSePage extends BasePage {
    @FindBy(xpath = "//input[@type=\"radio\" and @value=\"person\"]")
    WebElement radioButtonFizickoLice;
    @FindBy(xpath = "//input[@type=\"radio\" and @value=\"company\"]")
    WebElement radioButtonPravnoLice;
    @FindBy(id="UserName")
    WebElement username;

    @FindBy(id="Email")
    WebElement email;
    @FindBy(id="Password")
    WebElement password;
    @FindBy(id="ConfirmPassword")
    WebElement confirmPassword;
    @FindBy(id="AllowSendingNewsletters")
    WebElement allowNewslettersCheckBox;
    @FindBy(id="HasAgreedToGetFiscalReceiptByEmail")
    WebElement agreeToGetReceiptCheckBox;
    @FindBy(xpath = "//button[@type=\"button\" and @class=\"button-reg save save-entity person-face btn-main\"]")
    WebElement registerMeButton;
    @FindBy(css = "#divDetails > div.row.registration-step1 > div > div > div:nth-child(11) > div > div > a")
    WebElement alreadyHaveAnAccount;



   public RegistrujSePage(ChromeDriver driver){
       this.driver=driver;
       PageFactory.initElements(driver,this);
   }

   public void chooseType(String tip){

       switch (tip){
           case "personal":
               if(!radioButtonFizickoLice.isSelected()){
               radioButtonFizickoLice.click();}
               else
               {
               break;}
           case "legal":
               radioButtonPravnoLice.click();
               break;
       }
   }

   public void enterEmail(String eMail){email.sendKeys(eMail);}
   public void enterUsername(String user){username.sendKeys(user);}
   public void enterAndReEnterPassword(String pass){password.sendKeys(pass); confirmPassword.sendKeys(pass);}


    public void setAllowNewslettersCheckBox(){
     if(!allowNewslettersCheckBox.isSelected()){
         allowNewslettersCheckBox.click();
     }

    }

    public void setReceiptCheckBox(){

        if(!agreeToGetReceiptCheckBox.isSelected()){
            agreeToGetReceiptCheckBox.click();
        }
    }

    public void clickOnRegisterMeButton(){
       registerMeButton.click();
    }


}
