import org.openqa.selenium.PageLoadStrategy;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

public class BaseTest  {
    ChromeDriver driver;

    @BeforeMethod

    public void OpenChromeDriver() {


        System.setProperty("webdriver.chrome.driver", "/Users/dusanciric/IdeaProjects/HaloOglasi/Driver/chromedriver");

        ChromeOptions option=new ChromeOptions();
        option.setPageLoadStrategy(PageLoadStrategy.EAGER);
        driver = new ChromeDriver(option);

        driver.get("https://www.halooglasi.com/");

        driver.manage().window().maximize();
    }

    @AfterMethod

    public void CloseChromeDriver() {

       driver.quit();

    }

}
