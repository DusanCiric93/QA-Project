import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class SignInPage extends BasePage{

    @FindBy(id="EMailOrUsername")
    WebElement username;

    @FindBy(id="Password")
    WebElement password;

    @FindBy(id="remember-me")
    WebElement checkboxRemember;

    @FindBy(xpath = "//button[@type=\"button\" and @class=\"btn-main login-button login-user\"]")
    WebElement ulogujMeButton;

    @FindBy(xpath = "//*[@id=\"__AjaxAntiForgeryForm\"]/div[8]/div/div/a")
    WebElement registrujSe;

    @FindBy(xpath = "//*[@id=\"__AjaxAntiForgeryForm\"]/div[4]/div/div[3]/div[1]/a")
    WebElement zaboravljenaLozinka;

    @FindBy(xpath = "//input[@type=\"text\" and @name=\"forgot-user-email\"]")
    WebElement recoveryEmail;

    @FindBy(xpath = "//button[@type=\"button\" and @class=\"submit-password-request small\"]")
    WebElement resetujLozinku;

    @FindBy(xpath = "//*[@id=\"jquery-notific8-notification-7\"]/div[3]")
    WebElement shortUsername;



    public SignInPage(ChromeDriver driver){
        this.driver=driver;
        PageFactory.initElements(driver,this);

    }




    public void passwordForgottenOneStep(String email){
        zaboravljenaLozinka.click();
        recoveryEmail.sendKeys(email); // nece trebati
        resetujLozinku.click();
    }

    public void registerUser(){
        WebDriverWait w = new WebDriverWait(driver,4);
        w.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id=\"__AjaxAntiForgeryForm\"]/div[8]/div/div/a"))).click();

    }

    public void enterSignInUsername(String user){
        WebDriverWait w = new WebDriverWait(driver,4);
        w.until(ExpectedConditions.presenceOfElementLocated(By.id("EMailOrUsername"))).sendKeys(user);


    }

    public void enterSignInPassword(String pass){
        password.sendKeys(pass);
    }

    public  void rememberMe(){checkboxRemember.click();}

    public void clickOnSignInButton(){ ulogujMeButton.click();}

    public void closeFirstTab(){
        driver.close();
    }
}
