import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.Scanner;

public class MojProfilPage extends BasePage {
    @FindBy(id="fiscalReceiptModal")
    WebElement popUpAgreement;
    @FindBy (id="HasAgreedToGetFiscalReceiptByEmailModal")
    WebElement popUpAgreementButton;

    @FindBy(xpath = "//button[@type=\"button\" and text()=\"Potvrdi\"]")
    WebElement potvrdiButton;
    @FindBy(id="search-query")
    WebElement searchField;

    @FindBy(css = "#wrapper > div.header > div:nth-child(1) > div.widget-main-header-page.widget-main-header.main-header.fixed-main-header > div > section > div.col-lg-5.col-md-5.col-sm-8.col-xs-7 > div.header-category-link.set-product-btn-wrapper")
    WebElement dodajNoviOglas;
    public MojProfilPage(ChromeDriver driver){
        this.driver=driver;
        PageFactory.initElements(driver,this);
    }

    public void saglasnostPopUp(){

        if(popUpAgreement.isDisplayed()){
            popUpAgreementButton.click();
            potvrdiButton.click();
        }else{

        }
    }

    public void getDodajNoviOglas(){

        WebDriverWait w = new WebDriverWait(driver,4);

        w.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("#wrapper > div.header > div:nth-child(1) > div.widget-main-header-page.widget-main-header.main-header.fixed-main-header > div > section > div.col-lg-5.col-md-5.col-sm-8.col-xs-7 > div.header-category-link.set-product-btn-wrapper"))).click();




    }

    public void searchOglas(String search){

        searchField.sendKeys(search);
        searchField.sendKeys(Keys.ENTER);
    }


}
