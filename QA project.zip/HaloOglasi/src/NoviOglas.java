
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class NoviOglas extends BasePage{
    @FindBy(id="category-level1")
    WebElement prvaKategorija;

    @FindBy(xpath = "//input[@type=\"text\" and @name=\"Title\"]")
    WebElement naslovText;

    @FindBy(css="#tab2 > div.product-page.edit-mode.step2-new-ad.theme-blue.cat3297 > div.row > div.col-md-9.col-lg-10.custom-realestate.cat-37 > div.edit-page-ad > div:nth-child(2) > div > div.basic-data-container > div > div > div > div > div.one-field-container.col-md-12 > div.new-noa-style.type-vehicles.col-md-9 > div > div.trumbowyg-editor")
    WebElement opis;
    @FindBy(xpath = "//select[@name=\"stanje\"]")
    WebElement stanje;
    @FindBy(xpath = "//select[@name=\"proizvodjac\"]")
    WebElement proizvodjac;

    @FindBy(xpath = "//input[@type=\"text\" and @name=\"cena\"]")
    WebElement cena;

    @FindBy(xpath = "//select[@name=\"cena_unit\" and @class=\"form-control\"]")
    WebElement valuta;
    @FindBy(id="1171")
    WebElement muzikaIinstrumenti;

    @FindBy(id="3294")
    WebElement gitare;

    @FindBy(id="3297")
    WebElement elektricneGitare;

    @FindBy(id="531")
    WebElement knjige;

    @FindBy(id="535")
    WebElement fotoVideo;
    @FindBy(id="next")
    WebElement daljeButton;

    @FindBy(id="s2id_autogen1")
    WebElement mestoProdaje;

    @FindBy(id="select2-result-label-201")
    WebElement beograd;

    @FindBy(id="s2id_autogen2_search")
    WebElement gradInput;

    @FindBy(css="//span[@class=\"fileinput-button btn-main\"]")
    WebElement uploadPhoto;

    @FindBy(id="PhoneNumber1")
    WebElement telefon;

    @FindBy(id="PhoneNumber2")
    WebElement dodatniTelefon;

    @FindBy(id="Email")
    WebElement email;

    @FindBy(id="show-phone-auto")
    WebElement showPhoneNumberCheckBox;

    @FindBy(id="IsBought1")
    WebElement premiumOglas;
    @FindBy(id="IsBought2")
    WebElement topOglas;
    @FindBy(id="IsBought3")
    WebElement besplatanOglas;

    @FindBy(css = "#tab2 > div.col-md-9.col-lg-10 > div > div.pull-right > a")
    WebElement nextButton;

    @FindBy(xpath = "//button[@type=\"button\" and @class=\"submit-product btn-main\"]")
    WebElement predajOglasButton;






    public NoviOglas(ChromeDriver driver){
        this.driver= driver;
        PageFactory.initElements(driver,this);
    }

    public void izaberiKategoriju(){
        WebDriverWait w = new WebDriverWait(driver,4);
        w.until(ExpectedConditions.presenceOfElementLocated(By.id("1171"))).click();


    }

    public void izaberiPodKategoriju(){
        WebDriverWait w = new WebDriverWait(driver,4);
        w.until(ExpectedConditions.presenceOfElementLocated(By.id("3294"))).click();
    }

    public void izaberiTip(){
        WebDriverWait w = new WebDriverWait(driver,4);
        w.until(ExpectedConditions.presenceOfElementLocated(By.id("3297"))).click();
    }

    public void nextButton(){
        WebDriverWait w = new WebDriverWait(driver,4);
        w.until(ExpectedConditions.elementToBeClickable(By.id("next"))).click();
    }

    public void inputNaslov(String text){
        naslovText.sendKeys(text);
    }

    public void selectManufacturer(String text){

        WebDriverWait w = new WebDriverWait(driver,3);
        w.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//select[@name=\"proizvodjac\"]")));
        Select select = new Select(proizvodjac);
        select.selectByVisibleText(text);



    }

    public void selectConditionOfProduct(String text){
        WebDriverWait w = new WebDriverWait(driver,3);
        w.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//select[@name=\"stanje\"]")));
        Select select = new Select(stanje);
        select.selectByVisibleText(text);
    }

    public void selectCurrency(String text){
        Select select = new Select(valuta);
        select.selectByVisibleText(text);
    }

    public void price(String price){
     cena.sendKeys(price);
    }
    public void inputOpis(String text){
        WebDriverWait w = new WebDriverWait(driver,3);
        w.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("#tab2 > div.product-page.edit-mode.step2-new-ad.theme-blue.cat3297 > div.row > div.col-md-9.col-lg-10.custom-realestate.cat-37 > div.edit-page-ad > div:nth-child(2) > div > div.basic-data-container > div > div > div > div > div.one-field-container.col-md-12 > div.new-noa-style.type-vehicles.col-md-9 > div > div.trumbowyg-editor"))).sendKeys(text);

    }

    public void chooseCity(String grad){

        mestoProdaje.click();
gradInput.sendKeys(grad);
Actions action = new Actions(driver);
action.sendKeys(gradInput,Keys.RETURN).build().perform();

    }

    public void uploadPicture(){
        WebDriverWait w = new WebDriverWait(driver,3);

w.until(ExpectedConditions.elementToBeClickable(By.partialLinkText("Dodajte fotografiju"))).sendKeys("/Users/dusanciric/Desktop/fender\\ .jpeg");


    }

    public void phoneNumber(String number, String number2){

        telefon.sendKeys(number);
        dodatniTelefon.sendKeys(number2);

    }

    public void makePhoneVisibleCheckBox(){
        if(!showPhoneNumberCheckBox.isSelected()){
            showPhoneNumberCheckBox.click();
        }else{

        }
    }

    public void clickOnDaljeButton(){

        Actions actions = new Actions(driver);
        nextButton.click();
    }

    public void enterEmail(String emaill){

        email.clear();
        email.sendKeys(emaill);

    }

    public void izaberiteTipOglasa(String tipOglasa){

        WebDriverWait w = new WebDriverWait(driver,3);

      switch(tipOglasa){

          case "Premium oglas" :

              w.until(ExpectedConditions.elementToBeClickable(premiumOglas)).click();


              break;

          case "Top oglas" :

              w.until(ExpectedConditions.elementToBeClickable(topOglas)).click();
              break;

          case "Standardni oglas":

              w.until(ExpectedConditions.elementToBeClickable(besplatanOglas)).click();

              break;
      }

    }

    public void predajOglas(){
        predajOglasButton.click();
    }
}
