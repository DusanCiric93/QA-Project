import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

public class MojiOglasiPage extends BasePage {

@FindBy(xpath = "//input[@type=\"checkbox\" and @class=\"product-group-checkbox\"]")
WebElement selectSveOglase;

@FindBy(xpath = "//input[@type=\"checkbox\" and @value=\" \"]")
WebElement select1StOglas;

@FindBy(xpath = "//*[@id=\"tabMyAds\"]/div[2]/div[4]/div[4]/div/div/div[2]/div/div[3]/a[2]")
WebElement obrisi;

@FindBy(xpath = "//span[@class=\"my-total-products-number\"]")
WebElement brojOglasa;

@FindBy(xpath = "/html/body/div[11]/div/div/div[3]/button[1]")
WebElement obrisiOglasPop;

@FindBy(xpath = "/html/body/div[11]/div/div/div[3]/button[2]")
WebElement odustaniPop;


    public MojiOglasiPage(ChromeDriver driver){
        this.driver=driver;
        PageFactory.initElements(driver,this);
    }


    public void obrisiOglas(){
         WebDriverWait w = new WebDriverWait(driver,5);
         Actions action = new Actions(driver);
         this.select1StOglas= w.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@type=\"checkbox\" and @value=\" \"]")));
        action.click(select1StOglas).build().perform();
        this.obrisi= w.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id=\"tabMyAds\"]/div[2]/div[4]/div[4]/div/div/div[2]/div/div[3]/a[2]")));
        action.click(obrisi).build().perform();
        this.obrisiOglasPop=w.until(ExpectedConditions.visibilityOfElementLocated (By.xpath("/html/body/div[11]/div/div/div[3]/button[1]")));
        action.click(obrisiOglasPop).build().perform();
    }

    public void odustaniOdBrisanja(){

        WebDriverWait w = new WebDriverWait(driver,4);
        Actions action = new Actions(driver);
        this.select1StOglas= w.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@type=\"checkbox\" and @value=\" \"]")));
        action.click(select1StOglas).build().perform();

        this.obrisi= w.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id=\"tabMyAds\"]/div[2]/div[4]/div[4]/div/div/div[2]/div/div[3]/a[2]")));
        action.click(obrisi).build().perform();
        this.odustaniPop=w.until(ExpectedConditions.visibilityOfElementLocated (By.xpath("/html/body/div[11]/div/div/div[3]/button[2]")));
        action.click(odustaniPop).build().perform();


    }
}
