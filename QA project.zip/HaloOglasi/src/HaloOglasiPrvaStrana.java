import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HaloOglasiPrvaStrana extends BasePage{
    @FindBy(xpath = "//p[@class=\"cookie-policy-btn\"]")
    WebElement cookies;

    @FindBy(xpath = "//*[@id=\"wrapper\"]/header/div[1]/div[5]/div/section/div[2]/div[3]/a")
    WebElement ulogujSeButton;



    public HaloOglasiPrvaStrana(ChromeDriver driver){

        this.driver=driver;
        PageFactory.initElements(driver,this);

    }

    public void clickOnSingInButton(){
        ulogujSeButton.click();
    }

    public void acceptCookies(){

        if(cookies.isDisplayed()){
            cookies.click();
        }else {

        }
    }




}
