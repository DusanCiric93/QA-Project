import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.time.Duration;
import java.util.Iterator;
import java.util.Set;

public class MainTest extends BaseTest {

        public String email="wopeka5430@bitvoo.com"; // potrebno uneti novi email za svaku novu registraciju (temp mail)
        public String expectedShortUsername = "X\n" +
        "- \"E-mail ili korisničko ime\" mora imati između 3 i 100 karaktera.\n" +
        "\n" +
        "Nepopunjena obavezna polja i nepravilno popunjena polja označena su crvenom bojom.";;

        public String expectedUsernameDoesntExist = "X\n" +
                "- Neispravno korisničko ime ili lozinka.\n" +
                "\n" +
                "Nepopunjena obavezna polja i nepravilno popunjena polja označena su crvenom bojom.";

        public String expectedSuccesfulLoginPrekoMaila="Registracija je uspela!\n" +
                "\n" +
                "Kako bi Vaš nalog postao aktivan, neophodno je da kliknite na link u mejlu koji Vam je poslat na : \n"+email;

        public String expectedSuccesfulLogin="Registracija uspešna";

        public String slovnaMesta="Preostalo je još 1500 slovnih mesta";

        public String uspesanOglas="Uspešno ste predali internet oglas.";

        public String uspesnoObrisanOglas= "Uspešno ste obrisali oglas \"Fender Stratocaster\".";


@Test

    public void ShortUsernameError(){

HaloOglasiPrvaStrana ho= new HaloOglasiPrvaStrana(driver);
ho.acceptCookies();
ho.clickOnSingInButton();
SignInPage sip = new SignInPage(driver);
sip.enterSignInUsername("dd");
sip.enterSignInPassword("blabla");
sip.clickOnSignInButton();
WebDriverWait w = new WebDriverWait(driver,3);
w.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("body > div.jquery-notific8-container.top.right")));
String actual=  driver.findElement(By.cssSelector("body > div.jquery-notific8-container.top.right")).getText().toString();

Assert.assertEquals(actual,expectedShortUsername);

}

@Test

    public void WrongUsernameOrPassword(){
    HaloOglasiPrvaStrana ho= new HaloOglasiPrvaStrana(driver);
    ho.acceptCookies();
    ho.clickOnSingInButton();
    SignInPage sip = new SignInPage(driver);
    sip.enterSignInUsername("dusan.ciric9@gmail.com");
    sip.enterSignInPassword("blabla");
    sip.clickOnSignInButton();
    WebDriverWait w = new WebDriverWait(driver,3);
    w.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("body > div.jquery-notific8-container.top.right")));
    String actual=  driver.findElement(By.cssSelector("body > div.jquery-notific8-container.top.right")).getText().toString();
    Assert.assertEquals(actual,expectedUsernameDoesntExist);
    System.out.println("Neispravnan e-mail ili lozinka");

}

@Test

    public void RegisterUser(){
    HaloOglasiPrvaStrana ho= new HaloOglasiPrvaStrana(driver);
    ho.acceptCookies();
    ho.clickOnSingInButton();
    SignInPage sip = new SignInPage(driver);
    sip.registerUser();
    RegistrujSePage rp = new RegistrujSePage(driver);
    rp.chooseType("personal"); // personal legal
    rp.enterEmail(email);
    rp.enterUsername("nemoOjtedamebanuujeeeteplizmolimvssasvehee");
    rp.enterAndReEnterPassword("seleniummtestvezbanjeer");
    rp.setAllowNewslettersCheckBox();
    rp.setReceiptCheckBox();
    rp.clickOnRegisterMeButton();
    WebDriverWait w = new WebDriverWait(driver,10);
    w.until(ExpectedConditions.presenceOfElementLocated(By.id("jquery-notific8-notification-1")));
    String actual = driver.findElement(By.cssSelector("#jquery-notific8-notification-1 > div.jquery-notific8-message")).getText();
    Assert.assertEquals(actual,expectedSuccesfulLogin);
}


@Test

    public void dodajNoviOglas()  {
    HaloOglasiPrvaStrana ho= new HaloOglasiPrvaStrana(driver);
    ho.acceptCookies();
    ho.clickOnSingInButton();
    SignInPage sip= new SignInPage(driver);
    sip.enterSignInUsername("dusan.ciric993@gmail.com");
    sip.enterSignInPassword("1324567");
    sip.clickOnSignInButton();
    MojProfilPage mpp = new MojProfilPage(driver);
//    String originalTab =driver.getWindowHandle();
    mpp.getDodajNoviOglas();
    Set<String> tabovi = (driver.getWindowHandles());
    Iterator <String> iterator = tabovi.iterator();
    String originalTab = iterator.next();
    String drugi = iterator.next();
    driver.switchTo().window(drugi);
    NoviOglas no = new NoviOglas(driver);

//   Set<String> tabovi = (driver.getWindowHandles()); // moze i Array
//    for(String sledeci: tabovi){
//        if(!sledeci.equals(originalTab)){
//            driver.switchTo().window(sledeci);
//        }
//    }

    no.izaberiKategoriju();
    no.izaberiPodKategoriju();
    no.izaberiTip();
    no.nextButton();
    no.selectManufacturer("Fender");
    no.selectConditionOfProduct("Novo"); // Novo Polovno
    no.inputNaslov("Fender Stratocaster");
    no.inputOpis("Opis oglasa");
    WebElement slovna = driver.findElement(By.cssSelector("#tab2 > div.product-page.edit-mode.step2-new-ad.theme-blue.cat3297 > div.row > div.col-md-9.col-lg-10.custom-realestate.cat-37 > div.edit-page-ad > div:nth-child(2) > div > div.basic-data-container > div > div > div > div > div.one-field-container.col-md-12 > div.new-noa-style.type-vehicles.col-md-9 > div > span"));
    String actualSlovnaMesta = slovna.getText().toString();
    Assert.assertNotEquals(actualSlovnaMesta,slovnaMesta);
    no.selectCurrency("EUR"); // EUR RSD
    no.price("200");
    no.chooseCity("Beograd");
    no.phoneNumber("0603724975","0603724875");
    no.enterEmail("dusan.ciric993@gmail.com");
    no.clickOnDaljeButton();
    no.izaberiteTipOglasa("Standardni oglas"); // Premium oglas , Top oglas , Standardni oglas
    no.predajOglas();
    WebDriverWait w = new WebDriverWait(driver,5);
    String actual= w.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class=\"success-ad-msg\"]"))).getText().toString();
    Assert.assertEquals(actual,uspesanOglas);

}

@Test

    public void izbrisiOglas(){

    HaloOglasiPrvaStrana ho= new HaloOglasiPrvaStrana(driver);
    ho.acceptCookies();
    ho.clickOnSingInButton();
    SignInPage sip= new SignInPage(driver);
    sip.enterSignInUsername("dusan.ciric993@gmail.com");
    sip.enterSignInPassword("1324567");
    sip.clickOnSignInButton();
    MojiOglasiPage mop = new MojiOglasiPage(driver);
    WebDriverWait w = new WebDriverWait(driver,5);
    String brojOglasa = w.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[@class=\"my-total-products-number\"]"))).getText().toString();
    mop.obrisiOglas();
    String  brojOglasaPosleBrisanja=    w.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[@class=\"my-total-products-number\"]"))).getText().toString();
    Assert.assertEquals(brojOglasaPosleBrisanja, brojOglasa);
    String actualPoruka = w.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("#jquery-notific8-notification-1 > div.jquery-notific8-message"))).getText().toString();
    Assert.assertEquals(actualPoruka,uspesnoObrisanOglas);





}





}
